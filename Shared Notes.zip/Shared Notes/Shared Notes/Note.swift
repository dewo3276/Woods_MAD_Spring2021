//
//  note.swift
//  Shared Notes
//
//  Created by Dusty on 3/30/21.
//

import Foundation
import FirebaseFirestoreSwift

struct Note: Codable, Identifiable {
    @DocumentID var id: String?
    var note: String
    var title: String
}
