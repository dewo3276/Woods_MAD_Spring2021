//
//  addNoteController.swift
//  Shared Notes
//
//  Created by Dusty on 3/30/21.
//

import UIKit

class addNoteController: UIViewController {

    var addNote = String()
    var addTitle = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var titleAdd: UITextField!
    
    @IBOutlet weak var noteAdd: UITextField!
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "saveSegue"{
            if (titleAdd.text?.isEmpty == false && noteAdd.text?.isEmpty == false)
            {
                addTitle=titleAdd.text!
                addNote=noteAdd.text!
            }
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
