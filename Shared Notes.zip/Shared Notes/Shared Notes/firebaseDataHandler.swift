//
//  firebaseDataHandler.swift
//  Shared Notes
//
//  Created by Dusty on 3/18/21.
//
import Foundation
import FirebaseFirestore
import FirebaseFirestoreSwift

class firebaseDataHandler {
    let db = Firestore.firestore()
    
    var noteData = [Note]()
    
    //property with a closure as its value
    //closure takes an array of Recipe as its parameter and Void as its return type
    var onDataUpdate: ((_ data: [Note]) -> Void)?
    
    func dbSetup(){
        db.collection("JotDown")
            .addSnapshotListener {querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching snapshot results: \(error!)")
                    return
                }
                self.noteData = documents.compactMap {document-> Note? in
                    return try? document.data(as: Note.self)
                }
                //passing the results to the onDataUpdate closure
                self.onDataUpdate?(self.noteData)
            }
    }
    
    func addNote(note:String, title:String){
        let noteCollection = db.collection("JotDown")
        
        //create Dictionary
        let newNoteDict = ["Note": note, "Title": title]
        
        // Add a new document with a generated id
        var ref: DocumentReference? = nil
        ref = noteCollection.addDocument(data: newNoteDict) {err in
            if let err = err {
                print("Error adding document: \(err)")
            } else {
                print("Document added with ID: \(ref!.documentID)")
            }
        }
    }
    
    func deleteNote(noteId: String){
        // Delete the object from Firebase
        db.collection("JotDown").document(noteId).delete() { err in
            if let err = err {
                print("Error removing document: \(err)")
            } else {
                print("Document successfully removed!")
            }
        }
    }

    func getNotes()->[Note]{
        return noteData
    }

}
